def include(root, name):
	root = "/%s/" % root
	i = __file__.rfind(root)
	if i < 0: return
	i += len(root)
	root = __file__[:i]
	tail = __file__[i:]
	path = name.replace(".", "/") + ".py"

	import os.path
	path = os.path.join(root, path)
	if not os.path.isfile(path): return

	import importlib.util
	spec = importlib.util.spec_from_file_location(name, path)
	module = importlib.util.module_from_spec(spec)
	
	import sys
	sys.modules[name] = module
	spec.loader.exec_module(module)
	return module
